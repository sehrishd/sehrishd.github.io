# HCDE 439 Physical Computing Autumn 2025

**Instructors:** Blair Subbaraman and Danli Luo

This is an example of a student page for HCDE439. Feel free to use this as a template, or create your own!
